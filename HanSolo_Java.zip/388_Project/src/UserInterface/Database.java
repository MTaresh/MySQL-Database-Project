

package UserInterface;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Database {
    private String connectionUrl = "jdbc:mysql://localhost/cantina?user=root&password=admin";
    private List<String> currentOrders;
    private List<String> pastOrders;
    
    public Database() {
        currentOrders = new ArrayList();
        pastOrders = new ArrayList();
    }
    
    public String viewCurrentOrders() {
        String orders = "";
        for (String item : currentOrders) {
            orders += item + "\n";
        }
        return orders;
    }
    
    public String viewPastOrders() {
        String orders = "";
        for (String item : pastOrders) {
            orders += item + "\n";
        }
        return orders;
    }
    
    public void bumpOrder() {
        String order = currentOrders.get(0);
        String[] parts = order.split(",");
        int ID = Integer.parseInt(parts[0]);
        
        PreparedStatement stmt = null;
        String SQL = "DELETE FROM orderqueue "
                + "WHERE OrderID = ?";
        String move = "INSERT INTO completedorders"
                + "(OrderID,CustomerName,FirstItem,SecondItem,ThirdItem,FourthItem) "
                + "(SELECT OrderID,CustomerName,FirstItem,SecondItem,ThirdItem,FourthItem "
                + "FROM orderqueue WHERE OrderID = ?)";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            stmt = con.prepareStatement(move);
            stmt.setInt(1,ID);
            stmt.executeUpdate();
            
            stmt = con.prepareStatement(SQL);
            stmt.setInt(1,ID);
            stmt.executeUpdate();
            
            
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
        
        
    }
    
    public void getCurrentOrders() {
        currentOrders.clear();
        String orders = "";
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT * FROM orderqueue ORDER BY OrderID";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                orders = rs.getString("OrderID") + "," + rs.getString("CustomerName") + ", " + rs.getString("FirstItem")+ ", " + 
                        rs.getString("SecondItem") + ", " + rs.getString("ThirdItem") +
                        ", " + rs.getString("FourthItem");
                currentOrders.add(orders);
                orders = "";
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
    public void getPreviousOrders() {
        pastOrders.clear();
        String orders = "";
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT * FROM completedorders";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                orders += rs.getString("OrderID") + ", " + rs.getString("CustomerName") + ", " + rs.getString("FirstItem")+ ", " + 
                        rs.getString("SecondItem") + ", " + rs.getString("ThirdItem") +
                        ", " + rs.getString("FourthItem");
                pastOrders.add(orders);
                orders = "";
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
    public float getPrice(String item) {
        float price = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT MenuPrice FROM prices WHERE MenuName = '"+item+"'";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                price = rs.getFloat("MenuPrice");
            }
            return price;
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return 0;
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return 0;
        }
    }
    
    public void newOrder(String user, String first, String second, String third, String fourth) {
        int ID = getOrderID() + 1;
        PreparedStatement stmt = null;
        String SQL = "INSERT INTO orderqueue"
                + "(OrderID,CustomerName,FirstItem,SecondItem,ThirdItem,FourthItem) VALUES"
                + "(?,?,?,?,?,?)";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            stmt = con.prepareStatement(SQL);
            
            stmt.setInt(1,ID);
            stmt.setString(2,user);
            stmt.setString(3,first);
            stmt.setString(4,second);
            stmt.setString(5,third);
            stmt.setString(6, fourth);
            
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
    public int getOrderID() {
        //Returns highest orderID
        int num = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT OrderID FROM orderqueue";
            String SQL2 = "SELECT OrderID FROM completedorders";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                int high = rs.getInt("OrderID");
                if (high > num) num = high;
            }
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                int high = rs.getInt("OrderID");
                if (high > num) num = high;
            }
            return num;
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return 0;
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return 0;
        }
    }
    
    public String getCustomerStats() {
        String stats = "";
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT CustomerName,OrdersCompleted FROM customer";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                stats += rs.getString("CustomerName") + "," + rs.getString("OrdersCompleted") + "\n";
            }
            return stats;
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return "error";
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return "error";
        }
    }
    
    public String getIngredients() {
        String string = "";
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT IngredientName,IngredientTotal FROM ingredients";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                string += rs.getString("IngredientName") + "," + rs.getString("IngredientTotal") + "\n";
            }
            return string;
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return "error";
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return "error";
        }
    }
    
    public int getIngTotal(String item) {
        int price = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT IngredientTotal FROM ingredients WHERE IngredientName = '"+item+"'";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                price = rs.getInt("IngredientTotal");
            }
            return price;
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return 0;
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return 0;
        }
    }
    
    public void subtractIngredients(String MenuItem) {
        if (MenuItem == null) {
            return;
        }
        PreparedStatement stmt = null;
        String ing1 = null;
        String ing2 = null;
        String ing3 = null;
        String ing4 = null;
        String update = "UPDATE ingredients "
                + "SET IngredientTotal = ? "
                + "WHERE IngredientName = ?";
        String ingredient = "SELECT PrimaryIngredient,ExIng1,ExIng2,ExIng3 "
                + "FROM menuitem "
                + "WHERE MenuName = '"+MenuItem+"'";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            stmt = con.prepareStatement(ingredient);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ing1 = rs.getString("PrimaryIngredient");
                ing2 = rs.getString("ExIng1");
                ing3 = rs.getString("ExIng2");
                ing4 = rs.getString("ExIng3");
            }
            
            stmt = con.prepareStatement(update);
            
            stmt.setInt(1, getIngTotal(ing1)-1);
            stmt.setString(2, ing1);
            stmt.executeUpdate();
            
            if (getIngTotal(ing1)<50) {
                JOptionPane.showMessageDialog(null,"Warning:"+ing1+" ingredient count low. " + 
                        getIngTotal(ing1) + " portions remain.");
            }
            
            if (ing2 != null) {
                stmt.setInt(1, getIngTotal(ing2)-1);
                stmt.setString(2, ing2);
                stmt.executeUpdate();
                if (getIngTotal(ing2)<50) {
                JOptionPane.showMessageDialog(null,"Warning: "+ing2+" ingredient count low. " + 
                        getIngTotal(ing2) + " portions remain.");
            }
            }
            if (ing3 != null) {
                stmt.setInt(1, getIngTotal(ing3)-1);
                stmt.setString(2, ing3);
                stmt.executeUpdate();
                if (getIngTotal(ing3)<50) {
                JOptionPane.showMessageDialog(null,"Warning: "+ing3+" ingredient count low. " + 
                        getIngTotal(ing3) + " portions remain.");
            }
            }
            if (ing4 != null) {
                stmt.setInt(1, getIngTotal(ing4)-1);
                stmt.setString(2, ing4);
                stmt.executeUpdate();
                if (getIngTotal(ing4)<50) {
                JOptionPane.showMessageDialog(null,"Warning: "+ing4+" ingredient count low. " + 
                        getIngTotal(ing4) + " portions remain.");
            }
            }
            
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
    public void setIngredients() {
        String ingredient = JOptionPane.showInputDialog("Please enter ingredient");
        int amount = Integer.parseInt(JOptionPane.showInputDialog("Please enter new amount"));
        
        
        PreparedStatement stmt = null;
        String update = "UPDATE ingredients "
                + "SET IngredientTotal = ? "
                + "WHERE IngredientName = ?";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            stmt = con.prepareStatement(update);
            
            stmt.setInt(1, amount);
            stmt.setString(2, ingredient);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
    public ArrayList<String> getUsers() {
        ArrayList<String> list = new ArrayList();
        String user = null;
        try {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            
            Statement stmt = null;
            ResultSet rs = null;
            String SQL = "SELECT CustomerName FROM customer";
            stmt = con.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                user = rs.getString("CustomerName");
                list.add(user);
            }
            return list;
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
            return null;
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
            return null;
        }
        
    }
    
    public void addUserTotal(String user) {
        String getNumber = "SELECT OrdersCompleted FROM customer "
                + "WHERE CustomerName = '" + user + "'";
        String update = "UPDATE customer "
                + "SET OrdersCompleted = ? "
                + "WHERE CustomerName = '"+user+"'";
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int total = 0;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(connectionUrl);
            stmt = con.prepareStatement(getNumber);
            rs = stmt.executeQuery();
            while (rs.next()) {
                total = rs.getInt("OrdersCompleted");
            }
            
            stmt = con.prepareStatement(update);
            stmt.setInt(1, total+1);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("SQL Exception: "+ e.toString());
        } catch (ClassNotFoundException cE) {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }

}
