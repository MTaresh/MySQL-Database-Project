

package UserInterface;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Order {
    private List<String> order;
    private float total = 0;
    private DecimalFormat df = new DecimalFormat("#,###,##0.00");
    
    public Order() {
        order = new ArrayList();
    }
    
    public List<String> getList() {
        return order;
    }
    
    public void addItem(String item, float cost) {
        if (order.size() < 4) {
            order.add(item);
            total += cost;
        } else {
            JOptionPane.showMessageDialog(null, "You may only choose 4 items per order");
        }
        
    }
    
    public void clear() {
        order.clear();
        total = 0;
    }
    
    public String total() {
        
        return df.format(total * 1.06);
    }
    
    
    
    @Override
    public String toString() {
        String list = "";
        for (String item : order) {
            list += item + ", ";
        }
        return "Items: " + list + "$" + total();
    }

}
